sap.ui.define([
	"opensap/Cinema/test/unit/controller/App.controller"
], function () {
	"use strict";
});